import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Image, Button, TouchableOpacity} from 'react-native';
import {AppLoading, Asset} from 'expo';



export default function App() {
  return (
    <View style={styles.container}>
     
      <Text style={styles.text}>Your health calculator.</Text>
      <TouchableOpacity style={styles.getStartedBtn}><Text>Get Started</Text></TouchableOpacity>
      </View>
  
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    aspectRatio: 0.8, 
    resizeMode: 'contain',
    paddingBottom: 0,
    marginBottom: 0,
  },
  textStyle: {
    marginTop: 0,
    paddingTop: 0,
  },
  getStartedBtn:{
    marginTop: 285,
    borderWidth: 1,
    height: 50, width: "62%",
    justifyContent: "center", alignItems: "center", borderRadius: 20, backgroundColor: "#28C0D1", borderColor: '#fff',
  },
  text:{
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  }
});
