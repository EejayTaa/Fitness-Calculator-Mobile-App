import FatCATEGORIES from '../src/FatCategories';
import BMICATEGORIES from '../src/BMICategories';
import React from 'react';
import { DataTable } from 'react-native-paper';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import {Card} from 'react-native-shadow-cards';
const LBMResults = ({route}) => {
  
  const boerMaleFinal = route.params.boerMale;
  const boerFemaleFinal = route.params.boerFemale; 
  
  const jamesMaleFinal = route.params.jamesMale;
  const jamesFemaleFinal = route.params.jamesFemale;
  const humeMaleFinal = route.params.humeMale;
  const humeFemaleFinal = route.params.humeFemale;
  const genderFinal = route.params.gender;
  var boerFinal = 0;
  var jamesFinal = 0;
  var humeFinal = 0;

  if(genderFinal == 'Male'){
    boerFinal = boerMaleFinal;
    jamesFinal = jamesMaleFinal;
    humeFinal = humeMaleFinal;
  }else if(genderFinal == 'Female'){
    boerFinal = boerFemaleFinal;
    jamesFinal = jamesFemaleFinal;
    humeFinal = humeFemaleFinal;
  }

    return (
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: 'white'}}>
          
          <View style={{alignItems: 'center', justifyContent: 'center', alignContent: 'center', marginTop: 50}}> 
            <Text style={{fontFamily: 'sans-serif-medium', fontSize: 25, color: '#000'}}>Results</Text>
            
            <Image style={{width: 280, height: 250}}resizeMode="contain"source={require('../assets/green.png')}></Image>
            
            <View style={{position: 'absolute', justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{fontSize: 50, fontFamily: 'sans-serif-medium', alignSelf: 'center', marginTop: 32}}>{boerFinal}</Text>
           
            <Text>Kilogram</Text>
            
            </View>
            
            </View>

            <Divider style={{ marginTop: 15,backgroundColor: '#96DA45' }} />
          <Card style={{marginTop: 25, marginBottom: 20}}>
          <DataTable>
              
    <DataTable.Header>
      <DataTable.Title>Formula</DataTable.Title>
      <DataTable.Title numeric>Lean Body Mass</DataTable.Title>
      
      
    </DataTable.Header>

    <DataTable.Row>
      <DataTable.Cell>Boer</DataTable.Cell>
      <DataTable.Cell numeric>{boerFinal}</DataTable.Cell>
      
    </DataTable.Row>

    <DataTable.Row>
    <DataTable.Cell>James</DataTable.Cell>
      <DataTable.Cell numeric>{jamesFinal}</DataTable.Cell>
     
    </DataTable.Row>
    <DataTable.Row>
    <DataTable.Cell>Hume</DataTable.Cell>
      <DataTable.Cell numeric>{humeFinal}</DataTable.Cell>
      
    </DataTable.Row>
</DataTable>

</Card>
          
            </SafeAreaView>
    );
};

const style = StyleSheet.create({
    header: {
        marginTop: 20,
        flexDirection: 'row',
    },
    scrollView: {
      marginHorizontal: 5
    },  
});

export default LBMResults;