import React from 'react';
import {View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity} from 'react-native';
import { color } from 'react-native-reanimated';

import COLORS from '../src/colors';
import {ListItem, Button, Icon, Avatar, Badge, withBadge} from 'react-native-elements';
import {Card} from 'react-native-shadow-cards';
import * as Font from 'expo-font';

const HomeScreen = ({navigation, route}) => {

  const firstName = route.params.loginFirstName;
  const lastName = route.params.loginLastName;
  const age = route.params.loginAge;
  const gender = route.params.loginGender;
  
  return(
    
    <SafeAreaView
      style={{flex: 1,
      paddingHorizontal: 20,
      backgroundColor: 'white'}}>
        
        <Image style={{marginTop: 15,width: 120, height: 50, alignContent: 'center', justifyContent: 'center', alignSelf: 'center'}} resizeMode="contain"source={require('../assets/logofinal.png')}></Image>
        <View style={{marginTop: 5, justifyContent: 'space-around'}}>
        <Card style={{paddingHorizontal: 15, marginTop: 5}}>
        <View style={{flexDirection: 'row'}}>
        <Image style={{margin: 13, width: 65, height: 55}}source={require('../assets/usericon.png')}></Image>
        <View style={{flexDirection: 'column', justifyContent: 'center'}}>
        <Text style={{marginLeft: 15, fontSize: 18, fontFamily: 'sans-serif-medium'}}>{firstName} {lastName}</Text>
        <Text style={{marginLeft: 15, fontSize: 15, fontFamily: 'sans-serif-light'}}>{age}, {gender}</Text>
        </View>
        </View>
        
        </Card>
        </View>
        <View style={{textAlign: 'left', flexDirection: 'row'}}>
          <Text style={{fontFamily: 'sans-serif-medium', marginTop: 15, textAlign: 'left', fontSize: 17}}>Dashboard</Text>
          <Image style={{width: 15, height: 15, marginTop: 16, marginLeft: 5, alignSelf: 'center'}}resizeMode="contain"source={require('../assets/sort-down.png')}></Image>
          </View>
          <View>
              <Card style={{marginTop: 10,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#FF6968'}}>
                  <TouchableOpacity onPress= {() => navigation.navigate('FatCalculatorScreen')}>
                  <View style={{flexDirection: 'row'}}>
                    <Image style={{width: 18, height: 18, alignContent: 'center', alignItems: 'center', justifyContent: 'center', marginTop: 5}}source={require('../assets/circlemaroon.png')}/>
                   <Text style={{paddingLeft: 8, fontSize: 18, fontFamily: 'sans-serif-medium',color: '#fff'}}>Body Fat Calculator</Text>
                  </View>
                  <Text style={{paddingLeft: 25, fontSize: 15, fontFamily: 'sans-serif-light',color: '#fff'}}>Determine your body fat percentage with our body fat calculator.</Text>
                  </TouchableOpacity>
                  
              </Card>
              <Card style={{marginTop: 10,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#7A54FF'}}>
                  <TouchableOpacity onPress= {() => navigation.navigate('BMICalculatorScreen')}>
                  <View style={{flexDirection: 'row'}}>
                  <Image style={{width: 18, height: 18, alignContent: 'center', alignItems: 'center', justifyContent: 'center', marginTop: 5}}source={require('../assets/circlepurple.png')}/>
                   <Text style={{paddingLeft: 8, fontSize: 18, fontFamily: 'sans-serif-medium', color: '#fff'}}>BMI Calculator</Text>
                  </View>
                  <Text style={{paddingLeft: 25, fontSize: 15, fontFamily: 'sans-serif-light', color: '#fff'}}>BMI is a measure of body fat based on 
                  height and weight that applies to adult 
                  men and women.</Text>
                  </TouchableOpacity>
              </Card>
              <Card style={{marginTop: 10,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#2AC3FF'}}>
                  <TouchableOpacity onPress= {() => navigation.navigate('BMRCalculatorScreen')}>
                  <View style={{flexDirection: 'row'}}>
                  <Image style={{width: 18, height: 18, alignContent: 'center', alignItems: 'center', justifyContent: 'center', marginTop: 5}}source={require('../assets/circleblue.png')}/>
                   <Text style={{paddingLeft: 8, fontSize: 18, fontFamily: 'sans-serif-medium', color: '#fff'}}>BMR Calculator</Text>
                  </View>
                  <Text style={{paddingLeft: 25, fontSize: 15, fontFamily: 'sans-serif-light', color: '#fff'}}>This calculator estimate the Total Daily Energy Expenditure (TDEE) of a person based on their age, physical characteristics, and activity level</Text>
                  </TouchableOpacity>
              </Card>
              <Card style={{marginTop: 12,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#96DA45'}}>
                  <TouchableOpacity onPress= {() => navigation.navigate('LBMCalculatorScreen')}>
                  <View style={{flexDirection: 'row'}}>
                  <Image style={{width: 18, height: 18, alignContent: 'center', alignItems: 'center', justifyContent: 'center', marginTop: 5}}source={require('../assets/circlegreen.png')}/>
                   <Text style={{paddingLeft: 8, fontSize: 18, fontFamily: 'sans-serif-medium', color: '#fff'}}>LBM Calculator</Text>
                  </View>
                  <Text style={{paddingLeft: 25, fontSize: 15, fontFamily: 'sans-serif-light', color: '#fff'}}>Computes a person's estimated lean body mass (LBM) based on body weight, height, gender, and age.</Text>
                  </TouchableOpacity>
                  
              </Card>
          </View>
          
      </SafeAreaView>
      
      
  );
  
};

const style = StyleSheet.create({
    header:{
        marginTop: 20,
        flexDirection: 'row',
    },
});
export default HomeScreen;