import React, {useState} from 'react';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { Card } from 'react-native-shadow-cards';
import { Provider as PaperProvider } from 'react-native-paper';
import {Button, TextInput, RadioButton, TextInputMask, ToggleButton} from 'react-native-paper';
const LBMCalculatorScreen = ({navigation}) => {
    Number.prototype.round = function(places) {
        return +(Math.round(this + "e+" + places)  + "e-" + places);
      }
      
    const [age, setAge] = useState('');
    const [weight, setWeight] = useState('');
    const [height, setHeight] = useState('');
    var weightInput = weight;
    var heightInput = height; 
    var ageInput = age;
    
    var LBMBoerMale = (0.407*weightInput) + (0.267*heightInput) -  19.2;
    LBMBoerMale = LBMBoerMale.round(1);
    var LBMBoerFemale = (0.252*weightInput) + (0.473*heightInput) - 48.3;
    LBMBoerFemale = LBMBoerFemale.round(1);
    var JamesMale = (1.1*weightInput) - 128*((weightInput/heightInput)*(weightInput/heightInput));
    JamesMale = JamesMale.round(1);
    var JamesFemale = (1.07*weightInput) - 148*((weightInput/heightInput)*(weightInput/heightInput));
    JamesFemale = JamesFemale.round(1);
    var HumeMale = (0.32810*weightInput) + (0.33929*heightInput) - 29.5336;
    HumeMale = HumeMale.round(1);
    var HumeFemale = (0.29569*weightInput) + (0.41813*heightInput) - 43.2933;
    HumeFemale = HumeFemale.round(1);

    const [value, setValue] = React.useState('left');
    const [checked, setChecked] = React.useState('first');
    return(
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: '#fafafa'}}>
             <View style={style.header}>
            <View>
            <Text style={{fontFamily: 'sans-serif-medium', marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Let's Calculate</Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Your Lean Body </Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Mass </Text>
            </View>
        </View>
        <View style= {{
              flex: 0,
              flexDirection:'column',
          }}>
          <Divider style={{ marginTop: 15,backgroundColor: '#96DA45' }} />
          
          </View>
          <View>
          <Card style={{marginTop: 18,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#fff'}}>
              <View style={{flexDirection: 'row', justifyContent: 'space-around', margin: 7}}>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Male</Text>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Female</Text>
              </View>
          <ToggleButton.Row onValueChange={value => setValue(value)} value={value}>
        <ToggleButton style={{width: '48.5%', height: 50, marginRight: 5, marginBottom: 12}}icon={require('../assets/male.png')} value="Male" color="#00D3FF"></ToggleButton>
        <ToggleButton style={{width: '48.5%', height: 50, marginLeft: 5, marginBottom: 12}}icon={require('../assets/female.png')} value="Female" color="#D1285C" />
        </ToggleButton.Row>
          <TextInput label="Age"mode="outlined" onChangeText={text => setAge(text)}/>
          <TextInput label="Weight(kg)"mode="outlined" onChangeText={text => setWeight(text)}/>
          <TextInput label="Height(cm)"mode="outlined" onChangeText={text => setHeight(text)}/>  
          </Card>
          </View>
          <Button style={{marginTop: 20, height: 50, alignItems: 'center', justifyContent: 'center', backgroundColor: '#96DA45'}}icon="arrow-right"mode="contained" onPress={() => navigation.navigate('LBMResults', {boerMale: LBMBoerMale, boerFemale: LBMBoerFemale, jamesMale: JamesMale, jamesFemale: JamesFemale, humeMale: HumeMale, humeFemale: HumeFemale, gender: value})}>Calculate </Button>
        </SafeAreaView>
    );
};
const style = StyleSheet.create({
    header:{
        marginTop: 20,
        flexDirection: 'row',
    },
});
export default LBMCalculatorScreen;