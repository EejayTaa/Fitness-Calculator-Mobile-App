import React, { useState } from 'react';
import {View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity} from 'react-native';
import { color } from 'react-native-reanimated';
import COLORS from '../src/colors';
import {ListItem, Icon, Avatar, Badge, withBadge} from 'react-native-elements';
import {TextInput, RadioButton, TextInputMask, ToggleButton, IconButton, Button, Surface } from 'react-native-paper';
import {Card} from 'react-native-shadow-cards';
import * as Font from 'expo-font';

const LoginScreen = ({navigation}) => {
    const [age, setAge] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');

    const [value, setValue] = React.useState('val');
    const [checked, setChecked] = React.useState('first');



  return(
      
    <SafeAreaView
      style={{flex: 1,
      paddingHorizontal: 20,
      backgroundColor: '#fafafa', alignContent: 'center', alignItems: 'center'}}>
        <View style={style.header}>
            <View style={{alignItems:'center', alignContent: 'center', justifyContent: 'center'}}>
            <Image style={{width: 190, height: 120, alignContent: 'center', alignItems: 'center', justifyContent: 'center'}}source={require('../assets/logofinal.png')} resizeMode="contain"></Image>
            </View>
         
        </View>
    
          <View>
              <Card style={{marginTop: 10,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#fff'}}>
                  <View style={{flexDirection: 'row'}}>
                   <Text style={{fontSize: 18, fontFamily: 'sans-serif-medium',color: '#000'}}>Please tell us something about yourself.</Text>
                  </View>
                  <View>
                  <TextInput style={{marginTop: 15}}label="First Name" mode="outlined" onChangeText = {(val) => setFirstName(val)}/>
                  <TextInput style={{marginTop: 15}}label="Last Name" mode="outlined"  onChangeText = {(val) => setLastName(val)}/>
                  <TextInput style={{marginTop: 15}}label="Age" mode="outlined" onChangeText = {(val) => setAge(val)}/>

                  <ToggleButton.Row style={{justifyContent: 'space-around', marginTop: 15}}onValueChange={value => setValue(value)} value={value}>
                  <ToggleButton style={{width: '48.5%', marginBottom: 12}}icon={require('../assets/male.png')} value="Male" color="#00D3FF"></ToggleButton>
                  <ToggleButton style={{width: '48.5%', marginBottom: 12}}icon={require('../assets/female.png')} value="Female" color="#D1285C" />
                  </ToggleButton.Row>
                  </View>
              </Card> 
                 
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Home', {loginFirstName: firstName, loginLastName: lastName, loginAge: age, loginGender: value})}>
          <Image source={require('../assets/arrowright.png')}></Image>
          </TouchableOpacity>
      </SafeAreaView>
      
  );
};

const style = StyleSheet.create({
    header:{
        marginTop: 20,
        flexDirection: 'row',
    },
    
});
export default LoginScreen;