
import BMRCATEGORIES from '../src/BMRCategories';
import React from 'react';
import { DataTable } from 'react-native-paper';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity, ScrollView, ImageBackground} from 'react-native';

import {Card} from 'react-native-shadow-cards';
import BMICATEGORIES from '../src/BMICategories';
const BMRResults = ({route}) => {


  const bmrFinalResults = route.params.bmrResults;
    return (
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: 'white'}}>
          
            <View style={{alignItems: 'center', justifyContent: 'center', alignContent: 'center', marginTop: 50}}> 
            <Text style={{fontFamily: 'sans-serif-medium', fontSize: 25, color: '#000'}}>Results</Text>
            
            <Image style={{width: 280, height: 250}}resizeMode="contain"source={require('../assets/blue.png')}></Image>
            
            <View style={{position: 'absolute', justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{fontSize: 50, fontFamily: 'sans-serif-medium', alignSelf: 'center', marginTop: 32}}>{bmrFinalResults}</Text>
           
            <Text>Calories/day</Text>
            
            </View>
            
            </View>
            <Divider style={{ marginTop: 15,backgroundColor: '#2AC3FF' }} />
           
          
          <Card style={{marginTop: 15, marginBottom: 15}}>
          <DataTable>
              
    <DataTable.Header>
      <DataTable.Title>Activity Level</DataTable.Title>
      <DataTable.Title numeric>Calorie</DataTable.Title>
      
    </DataTable.Header>

    <DataTable.Row>
      <DataTable.Cell>{BMRCATEGORIES.category1.activitylvl}</DataTable.Cell>
      <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.15)}</DataTable.Cell>
    </DataTable.Row>

    <DataTable.Row>
        <DataTable.Cell>{BMRCATEGORIES.category2.activitylvl}</DataTable.Cell>
        <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.30)}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
        <DataTable.Cell>{BMRCATEGORIES.category3.activitylvl}</DataTable.Cell>
        <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.40)}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
        <DataTable.Cell>{BMRCATEGORIES.category4.activitylvl}</DataTable.Cell>
        <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.50)}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
        <DataTable.Cell>{BMRCATEGORIES.category5.activitylvl}</DataTable.Cell>
        <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.65)}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
        <DataTable.Cell>{BMRCATEGORIES.category6.activitylvl}</DataTable.Cell>
        <DataTable.Cell numeric>{Math.round(bmrFinalResults*1.80)}</DataTable.Cell>
    </DataTable.Row>
</DataTable>

</Card>

            </SafeAreaView>
    );
};

const style = StyleSheet.create({
    header: {
        marginTop: 20,
        flexDirection: 'row',
    },
    scrollView: {
        
    },  
});

export default BMRResults;