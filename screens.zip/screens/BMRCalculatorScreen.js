import React, {useState} from 'react';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { Card } from 'react-native-shadow-cards';
import { Provider as PaperProvider } from 'react-native-paper';
import {Button, TextInput, RadioButton, TextInputMask, ToggleButton} from 'react-native-paper';
const BMRCalculatorScreen = ({navigation}) => {

   
    Number.prototype.round = function(places) {
        return +(Math.round(this + "e+" + places)  + "e-" + places);
      }
   
      const [age, setAge] = useState('');
      const [weight, setWeight] = useState('');
      const [height, setHeight] = useState('');
      
      var weightInput = weight;
      var heightInput = height; 
      var ageInput = age;

      var BMRmale = (13.75*weightInput) + (5.003*heightInput) - (6.755*ageInput) + 66.47;
      var BMRfemale = (9.563*weightInput) + (1.85*heightInput) - (4.676*ageInput) + 655.1;
      var BMRFinal = BMRmale.round(0);

    const [value, setValue] = React.useState('left');
    const [checked, setChecked] = React.useState('first');
    return(
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: '#fafafa'}}>
             <View style={style.header}>
            <View>
            <Text style={{fontFamily: 'sans-serif-medium', marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Let's Calculate</Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Your Basal </Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Metabolic Rate</Text>
            </View>
        </View>
        <View style= {{
              flex: 0,
              flexDirection:'column',
          }}>
          <Divider style={{ marginTop: 15,backgroundColor: '#2AC3FF' }} />
          
          </View>
          <View>
              <Card style={{marginTop: 18,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#fff'}}>
              <View style={{flexDirection: 'row', justifyContent: 'space-around'}}>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Male</Text>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Female</Text>
              </View>
          <ToggleButton.Row onValueChange={value => setValue(value)} value={value}>
        <ToggleButton style={{width: '48.5%', height: 50, marginRight: 5, marginBottom: 12}}icon={require('../assets/male.png')} value="left" color="#00D3FF"></ToggleButton>
        <ToggleButton style={{width: '48.5%', height: 50, marginLeft: 5, marginBottom: 12}}icon={require('../assets/female.png')} value="right" color="#D1285C" />
        </ToggleButton.Row>
          <TextInput label="Age"  mode="outlined" onChangeText={text => setAge(text)}/>
            <TextInput label="Weight(kg)"  mode="outlined" onChangeText={text => setWeight(text)}/>
             <TextInput label="Height(cm)"  mode="outlined" onChangeText={text => setHeight(text)}/>
             </Card>
          </View>
          <Button style={{marginTop: 20, height: 50, alignItems: 'center', justifyContent: 'center', backgroundColor: '#2AC3FF'}}icon="arrow-right"mode="contained" onPress={() => navigation.navigate('BMRResults', {bmrResults: BMRFinal})}>Calculate </Button>
        </SafeAreaView>
    );
};
const style = StyleSheet.create({
    header:{
        marginTop: 20,
        flexDirection: 'row',
    },
});
export default BMRCalculatorScreen;