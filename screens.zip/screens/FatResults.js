import FatCATEGORIES from '../src/FatCategories';
import BMICATEGORIES from '../src/BMICategories';
import React from 'react';
import { DataTable } from 'react-native-paper';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import {Card} from 'react-native-shadow-cards';


const FatResults = ({route}) => {
  var category = "";
  const bodyFatMale = route.params.bodyFatResultsMale;
  const bodyFatFemale = route.params.bodyFatResultsFemale;
  var bodyFat = 0;
  const gender = route.params.gender;
  
  if(gender == 'Male'){
    bodyFat = bodyFatMale;
    if(bodyFatMale >= 2 && bodyFatMale <= 5){
        category = "Essential Fat";
    } else if(bodyFatMale >=6 && bodyFatMale <= 13){
        category = "Athletes";
    } else if(bodyFatMale >= 14 && bodyFatMale <= 17){
        category = "Fitness";
    } else if(bodyFatMale >= 18 && bodyFatMale <= 24){
        category = "Average";
    } else if(bodyFatMale >= 25){
        category = "Obese";
    } else{
        category = "";
    }
  }else if(gender == 'Female'){
    bodyFat = bodyFatFemale;
    if(bodyFatFemale >= 10 && bodyFatFemale <= 13){
      category = "Essential Fat";
    } else if(bodyFatFemale >=14 && bodyFatFemale <= 20){
      category = "Athletes";
    } else if(bodyFatFemale >= 21 && bodyFatFemale <= 24){
      category = "Fitness";
    } else if(bodyFatFemale >= 25 && bodyFatFemale <= 31){
      category = "Average";
    } else if(bodyFatFemale >= 32){
      category = "Obese";
    } else{
      category = "";
    }
  }
    return (
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: 'white'}}>
          
          <View style={{alignItems: 'center', justifyContent: 'center', alignContent: 'center', marginTop: 50}}> 
            <Text style={{fontFamily: 'sans-serif-medium', fontSize: 25, color: '#000'}}>Results</Text>
            
            <Image style={{width: 280, height: 250}}resizeMode="contain"source={require('../assets/maroon.png')}></Image>
            
            <View style={{position: 'absolute', justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{fontSize: 50, fontFamily: 'sans-serif-medium', alignSelf: 'center', marginTop: 32}}>{bodyFat}</Text>
           
            <Text>Percentage</Text>
            
            </View>
            </View>
            <Divider style={{ marginTop: 15,backgroundColor: '#D1285C' }} />
          <Card style={{marginTop: 15}}>
          <DataTable>
              
    <DataTable.Header>
      <DataTable.Title>Description</DataTable.Title>
      <DataTable.Title numeric>Men</DataTable.Title>
      <DataTable.Title numeric>Women</DataTable.Title>
      
    </DataTable.Header>

    <DataTable.Row>
      <DataTable.Cell>{FatCATEGORIES.description1.category}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description1.men}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description1.women}</DataTable.Cell>
    </DataTable.Row>

    <DataTable.Row>
    <DataTable.Cell>{FatCATEGORIES.description2.category}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description2.men}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description2.women}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
    <DataTable.Cell>{FatCATEGORIES.description3.category}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description3.men}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description3.women}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
    <DataTable.Cell>{FatCATEGORIES.description4.category}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description4.men}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description4.women}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
    <DataTable.Cell>{FatCATEGORIES.description5.category}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description5.men}</DataTable.Cell>
      <DataTable.Cell numeric>{FatCATEGORIES.description5.women}</DataTable.Cell>
    </DataTable.Row>
</DataTable>

</Card>

            </SafeAreaView>
    );
};

const style = StyleSheet.create({
    header: {
        marginTop: 20,
        flexDirection: 'row',
    },
    scrollView: {
      marginHorizontal: 5
    },  
});

export default FatResults;