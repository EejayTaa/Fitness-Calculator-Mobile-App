import BMICATEGORIES from '../src/BMICategories';
import React from 'react';
import { DataTable } from 'react-native-paper';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity, ScrollView, Button } from 'react-native';
import {Card} from 'react-native-shadow-cards';

var categoryFinal = "";
var categoryColor = "";
const BMIResults = ({route}) => {
  const bmiFinalResults = route.params.bmiResults;
  if(bmiFinalResults <= 18.5){
    categoryFinal = 'Underweight';
    categoryColor = '#FF9913';
  }else if(bmiFinalResults > 18.5 && bmiFinalResults <= 24.9){
    categoryFinal = 'Normal Weight';
    categoryColor = '#96DA45';
  }else if(bmiFinalResults > 24.9 && bmiFinalResults <=35.0){
    categoryFinal = "Overweight";
    categoryColor = "#E1E11D";
  }else if(bmiFinalResults > 35.0 && bmiFinalResults <=39.9){
    categoryFinal = "Severe Obesity";
    categoryColor = "#EB0BA0";
  }else if(bmiFinalResults > 39.9 && bmiFinalResults <= 44.9){
    categoryFinal = "Morbid Obesity";
    categoryColor = "#EB0B57";
  }else if(bmiFinalResults > 44.9){
    categoryFinal = "Super Obesity";
    categoryColor = "#FF045A";
  }else{
    categoryFinal = "";
  }
    return (
      
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: 'white'}}>
         
          <View style={{alignItems: 'center', justifyContent: 'center', alignContent: 'center', marginTop: 50}}> 
            <Text style={{fontFamily: 'sans-serif-medium', fontSize: 25, color: '#000'}}>Results</Text>
            
            <Image style={{width: 280, height: 250}}resizeMode="contain"source={require('../assets/purple.png')}></Image>
            
            <View style={{position: 'absolute', justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{fontSize: 50, fontFamily: 'sans-serif-medium', alignSelf: 'center', marginTop: 32}}>{bmiFinalResults}</Text>
           
            <Text>Kilogram/m2</Text>
            
            </View>
            </View>
            <Divider style={{ marginTop: 15,backgroundColor: '#7A54FF' }} />
         
          
         
          <Card style={{marginTop: 15, marginBottom: 15}}>
          <DataTable>
              
    <DataTable.Header>
      <DataTable.Title>BMI Category</DataTable.Title>
      <DataTable.Title numeric>Classification</DataTable.Title>
      
    </DataTable.Header>

    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category1.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category1.classification}</DataTable.Cell>
    </DataTable.Row>

    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category2.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category2.classification}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category3.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category3.classification}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category4.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category4.classification}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category5.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category5.classification}</DataTable.Cell>
    </DataTable.Row>
    <DataTable.Row>
      <DataTable.Cell>{BMICATEGORIES.category6.weight}</DataTable.Cell>
      <DataTable.Cell numeric>{BMICATEGORIES.category6.classification}</DataTable.Cell>
    </DataTable.Row>
</DataTable>

</Card>

            </SafeAreaView>
    );
};

const style = StyleSheet.create({
    header: {
        marginTop: 20,
        flexDirection: 'row',
    },
    scrollView: {
      marginHorizontal: 5
    },  
});

export default BMIResults;