import React, {useState} from 'react';
import { View, Text, SafeAreaView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { ListItem, Icon, Avatar, Badge, withBadge, Divider, CheckBox } from 'react-native-elements';
import { Card } from 'react-native-shadow-cards';
import { Provider as PaperProvider } from 'react-native-paper';
import {Button, TextInput, RadioButton, TextInputMask, ToggleButton} from 'react-native-paper';
const FatCalculatorScreen = ({navigation}) => {
    Number.prototype.round = function(places) {
        return +(Math.round(this + "e+" + places)  + "e-" + places);
      }
    const [weight, setWeight] = useState('');
    const [age, setAge] = useState('');
    const [waist, setWaist] = useState('');
    const [value, setValue] = React.useState('');
    const [checked, setChecked] = React.useState('first');
    
   
    var weightInput = weight;
    var ageInput = age;
    var waistInput = waist;
    var gender = value;

    var bodyFatMale = ((4.15*waistInput - 0.082*weightInput-98.42)/weightInput) * 100;
    bodyFatMale = bodyFatMale.round(1);

    var bodyFatFemale = ((4.15*waistInput - 0.082*weightInput-76.76)/weightInput) * 100;
    bodyFatFemale = bodyFatFemale.round(1);
    
    
    return(
        <SafeAreaView
        style={{flex: 1,
        paddingHorizontal: 20,
        backgroundColor: 'white'}}>
             <View style={style.header}>
            <View>
            <Text style={{fontFamily: 'sans-serif-medium', marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Let's Calculate</Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Your Body Fat </Text>
            <Text style={{fontFamily: 'sans-serif-medium',marginTop: 8,fontSize: 35, fontWeight: 'bold', color: '#000'}}>Percentage </Text>
            </View>
        </View>
        <View style= {{
              flex: 0,
              flexDirection:'column',
          }}>
          <Divider style={{ marginTop: 15,backgroundColor: '#FF6968' }} />
          
          </View>
          <Card style={{marginTop: 18,padding: 20,cornerRadius: 1, elevation: 8, backgroundColor: '#fff'}}>
          <View>
              <View style={{flexDirection: 'row', justifyContent: 'space-around'}}>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Male</Text>
                  <Text style={{fontFamily: 'sans-serif-medium'}}>Female</Text>
              </View>
        <ToggleButton.Row style={{justifyContent: 'space-around', marginTop: 15}}onValueChange={value => setValue(value)} value={value}>
        <ToggleButton style={{width: '48.5%', height: 50, marginRight: 5, marginBottom: 12}}icon={require('../assets/male.png')} value="Male" color="#00D3FF"></ToggleButton>
        <ToggleButton style={{width: '48.5%', height: 50, marginLeft: 5, marginBottom: 12}}icon={require('../assets/female.png')} value="Female" color="#D1285C" />
        </ToggleButton.Row>
          <TextInput label="Age" mode="outlined" onChangeText={(val) => setAge(val)} />
            <TextInput label="Weight(lb)" mode="outlined" onChangeText={text => setWeight(text)}/>
             <TextInput label="Waist(in)" mode="outlined" onChangeText={text => setWaist(text)}/>
          </View>
          </Card>
          <Button style={{marginTop: 20, height: 50, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FF6968'}}mode="contained" icon="arrow-right"onPress={() => navigation.navigate('FatResults',{bodyFatResultsMale: bodyFatMale, bodyFatResultsFemale: bodyFatFemale,gender: gender })}>Calculate </Button>
        </SafeAreaView>
    );
};
const style = StyleSheet.create({
    header:{
        marginTop: 20,
        flexDirection: 'row',
    },
});
export default FatCalculatorScreen;