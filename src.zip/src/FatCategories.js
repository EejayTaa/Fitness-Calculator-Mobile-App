const FatCategory = {
    description1: {
        category: 'Essential Fat',
        men: '2-5%',
        women: '10-13%',
    },
    description2: {
        category: 'Athletes',
        men: '6-13%',
        women: '14-20%',
    },
    description3: {
        category: 'Fitness',
        men: '14-17%',
        women: '21-24%',
    },
    description4: {
        category: 'Average',
        men: '18-24%',
        women: '25-31%',
    },
    description5: {
        category: 'Obese',
        men: '25&+',
        women: '32%+',
    },

};

export default FatCategory;