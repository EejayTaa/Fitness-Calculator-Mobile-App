const BMRCATEGORIES = {
    category1: {
        activitylvl: 'Sedentary: little or no exercise',
        calorie: '1,926',
    },
    category2: {
        activitylvl: 'Exercise 1-3 times/week',
        calorie: '2,207',
    },
    category3: {
        activitylvl: 'Exervise 4-5 times/week',
        calorie: '2,351',
    },
    category4: {
        activitylvl: 'Daily Exercise or intense exercise 3-4 times/week',
        calorie: '2,488',
    },
    category5: {
        activitylvl: 'Intense exercise 6-7 times/week',
        calorie: '2,769',
    },
    category6: {
        activitylvl: 'Very intense exercise daily, or physical job',
        calorie: '3,050',
    },
};
export default BMRCATEGORIES;