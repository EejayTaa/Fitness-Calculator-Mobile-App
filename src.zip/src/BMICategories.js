const BMICATEGORIES = {
    category1: {
        weight: 'Below 18.5',
        classification: 'Underweight',
    },
    category2: {
        weight: '18.5 - 24.9',
        classification: 'Normal weight',
    },
    category3: {
        weight: '25.0 - 29.9',
        classification: 'Overweight',
    },
    category4: {
        weight: '35.0 - 39.5',
        classification: 'Severe Obesity',
    },
    category5: {
        weight: '40 - 44.5',
        classification: 'Morbid Obesity',
    },
    category6: {
        weight: '45 - greater',
        classification: 'Super obesity',
    },
};

export default BMICATEGORIES;